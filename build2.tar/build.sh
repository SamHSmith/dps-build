#!/bin/sh

make -C sbase sbase-box

cp sbase/sbase-box sbase/sbase-box2

sbase/sbase-box | sed 's/\[ //g' | sed 's/ /\n/g' | sed -e '${/^$/d}' | awk '{printf "sbase/sbase-box:/bin/"; print $1}' > register

sbase/sbase-box2 | sed 's/\[ //g' | sed 's/ /\n/g' | sed -e '${/^$/d}' | awk '{printf "sbase/sbase-box2:/bin2/"; print $1}' >> register


