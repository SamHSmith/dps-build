#!/bin/sh

make -C sbase sbase-box

sbase/sbase-box | sed 's/\[ //g' | sed 's/ /\n/g' | sed -e '${/^$/d}' | awk '{printf "sbase/sbase-box:/bin/"; print $1}' > register

cd sbase

find . | grep -F .1 | sed 's/.//' | awk '{printf "sbase"; printf $0; printf ":/share/man/man1"; print $0}' >> ../register
