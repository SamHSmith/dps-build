#!/bin/sh

DESTDIR=../install make -C sbase sbase-box-install

cd install

find . -type f,l | sed 's/.//' | awk '{printf "install"; printf $0; printf ":"; print $0}' > ../register
