#!/bin/sh

chmod +x run.sh
echo "run.sh:/usr/bin" >> register
echo "run.sh:/sbin" >> register
